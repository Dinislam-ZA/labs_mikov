package org.example

object TextPage {
    fun getPage(): String = """
        <html>
        <body alink="green">
            <ol type="I">
                <li>Поступающие в аспирантуру проходят собеседование с предполагаемым научным руководителем.</li>
                <li>Личный листок по учету кадров заполняется в отделе аспирантуры.</li>
                <li>Документы, необходимые для поступления в аспирантуру:</li>
            </ol>
            <ul>
                <li>заявление;</li>
                <li>фотографии;</li>
                <li>диплом и приложение;</li>
                <li>паспорт;</li>
            </ul>
            <p>Сайт университета: <a href="https://bmstu.ru">bmstu.ru</a></p>
        </body>
        </html>
    """.trimIndent()
}